import MyComponent from './MyComponent';
import MyComponent2 from './MyComponent2';
import MyComponent3 from './MyComponent3';

export { MyComponent, MyComponent2, MyComponent3 };
